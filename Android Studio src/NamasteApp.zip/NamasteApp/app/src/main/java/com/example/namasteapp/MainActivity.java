package com.example.namasteapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

import java.util.Objects;


public class MainActivity extends AppCompatActivity {

    WebView webView;
    ProgressBar progressBar;
    Boolean errorr=false;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        progressBar=findViewById(R.id.progressBar);
        webView=findViewById(R.id.web);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.addJavascriptInterface(new WebAppInterface(this), "Android");
        webView.setWebViewClient(new WebViewClient());
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setPluginState(WebSettings.PluginState.ON);
        webView.getSettings().setMediaPlaybackRequiresUserGesture(false);
        webView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
//        webView.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);

        Objects.requireNonNull(getSupportActionBar()).setElevation(0);
        Objects.requireNonNull(getSupportActionBar()).hide();

        webView.setWebChromeClient(new WebChromeClient() {

            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                Log.d("Permission Request", "onPermissionRequest: ");
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    request.grant(request.getResources());
                }
            }


            @Override
            public Bitmap getDefaultVideoPoster() {
                return super.getDefaultVideoPoster();
            }
        });

//       change ip if required
        loadWeb("https://3.84.117.2:3000");




        // Create the NotificationChannel, but only on API 26+ because
        // the NotificationChannel class is new and not in the support library
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "app";
            String description = "none";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel("1", name, importance);
            channel.setDescription(description);
            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            assert notificationManager != null;
            notificationManager.createNotificationChannel(channel);
        }


    }


    @Override
    protected void onStart() {
        super.onStart();
        permissionRequest();
    }

//    @Override
//    protected void onResume() {
//        super.onResume();
//        permissionRequest();
//    }

//    @Override
//    protected void onRestart() {
//        super.onRestart();
//        permissionRequest();
//    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
//        Log.d("permissions",Integer.toString(grantResults[0]));
//        Log.d("permissions",Integer.toString(grantResults[1]));
        if(requestCode==0 && (grantResults[0]==PackageManager.PERMISSION_DENIED)||grantResults[1]==PackageManager.PERMISSION_DENIED){
            AlertDialog.Builder builder=new AlertDialog.Builder(this);
            builder.setTitle("Alert");
            builder.setMessage("Requested Permissions are not granted. Please grant it to continue using this app.");
            builder.setCancelable(false);
            builder.setNegativeButton("Go to Settings", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                    Uri uri = Uri.fromParts("package", getPackageName(), null);
                    intent.setData(uri);
                    startActivity(intent);
                }
            });

            builder.setPositiveButton("Exit", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    finish();
                }
            });

            AlertDialog alertDialog=builder.create();
            alertDialog.show();
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    void permissionRequest(){

        if(ContextCompat.checkSelfPermission(this , Manifest.permission.CAMERA)!= PackageManager.PERMISSION_GRANTED||ContextCompat.checkSelfPermission(this , Manifest.permission.RECORD_AUDIO)!= PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.CAMERA,Manifest.permission.RECORD_AUDIO},0);
        }
    }

    void loadWeb(String url){
        webView.loadUrl(url);
    }



    //webview client
    public class WebViewClient extends android.webkit.WebViewClient{


        /*@Override
        public void onLoadResource(WebView view, String url) {
            web.setVisibility(View.INVISIBLE);
            if(!progressBar.isShown())
                progressBar.setVisibility(View.VISIBLE);
            super.onLoadResource(view, url);
        }*/

        /*@Override
        public void onReceivedClientCertRequest(WebView view, ClientCertRequest request) {
            Log.d("WebviewCheck","cert Working");
            request.proceed(privateKey, cert);
        }*/

        @Override
        public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
            handler.proceed();
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            if (true) {

//                CookieSyncManager.getInstance().sync();
                webView.setVisibility(View.INVISIBLE);
                if (!progressBar.isShown())
                    progressBar.setVisibility(View.VISIBLE);
                super.onPageStarted(view, url, favicon);
            }
            else{
                webView.stopLoading();
            }

        }

        @Override
        public void onReceivedError(WebView view, int errorCode, String description, final String failingUrl) {
            errorr=true;
            webView.stopLoading();
            if(progressBar.isShown())
                progressBar.setVisibility(View.GONE);
            webView.setVisibility(View.INVISIBLE);
            AlertDialog.Builder builder=new AlertDialog.Builder(MainActivity.this);
            builder.setTitle("Error");
            builder.setMessage("Check your connection and try again");
            builder.setCancelable(false);
            builder.setPositiveButton("Try again", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    loadWeb(failingUrl);
                }
            });
            builder.show();
            super.onReceivedError(view, errorCode, description, failingUrl);
        }

        @Override
        public void onPageFinished(WebView view, String u) {
            if (android.os.Build.VERSION.SDK_INT >= 21) {
                CookieManager.getInstance().setAcceptCookie(true);

                CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
                CookieManager.getInstance().flush();

            } else {

                CookieManager.getInstance().setAcceptCookie(true);

            }
//            CookieSyncManager.getInstance().sync();
            if (errorr) {
                errorr=false;
                webView.setVisibility(View.INVISIBLE);
            } else{
                webView.setVisibility(View.VISIBLE);
                if (progressBar.isShown())
                    progressBar.setVisibility(View.GONE);
                //setTitle(view.getTitle());
//                if (clearHistory) {
//                    clearHistory = false;
//                    webView.clearHistory();
//                }
            }
            super.onPageFinished(view, u);
        }


        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
//            change ip if required
            if(url.contains("3.84.117.2")){
                if(!(url.contains("mobileUserAgent"))) url=url+"?mobileUserAgent=ys";
                view.loadUrl(url);
                return true;
            }
            return false;
        }


    }

    //javascript to native function call
    public class WebAppInterface {
        Context mContext;

        /** Instantiate the interface and set the context */
        WebAppInterface(Context c) {
            mContext = c;
        }

        /** Show a toast from the web page */
        @JavascriptInterface
        public void showToast(String toast) {
            Toast.makeText(mContext, toast, Toast.LENGTH_SHORT).show();
        }


        @JavascriptInterface
        public void not(String title,String message){
            notif(title,message);
        }


        @JavascriptInterface
        public void show_actionbar(){
            Objects.requireNonNull(getSupportActionBar()).show();
        }

        @JavascriptInterface
        public void dial(String tel){
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:"+tel));
            startActivity(intent);
        }

        @JavascriptInterface
        public void hide_actionbar(){
            Objects.requireNonNull(getSupportActionBar()).hide();
        }

        @JavascriptInterface
        public void snackBar(String msg){
            final Snackbar snackbar = Snackbar.make(findViewById(R.id.web),msg,1000);
            snackbar.show();
        }
    }



    void notif(String title,String msg){
        Intent intent = new Intent();
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, 0);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "1")
                .setSmallIcon(R.drawable.ic_notification_bell)
                .setContentTitle(title)
                .setContentText(msg)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);
        builder.setContentIntent(pendingIntent);
        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);

// notificationId is a unique int for each notification that you must define
        notificationManager.notify(1, builder.build());
    }


    @Override
    public void onBackPressed() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            CookieManager.getInstance().flush();
        }
        if(webView.canGoBack()){
            webView.goBack();
        }
        else {
            finish();
            super.onBackPressed();
        }
    }
}